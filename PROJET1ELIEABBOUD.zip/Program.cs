﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJET1ELIEABBOUD
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] tailles = { 10, 100, 1000 };//on va voir la difference avec 10,100 et 1000 elements.

            for (int tIndex = 0; tIndex < tailles.Length; tIndex++)
            {
                int taille = tailles[tIndex];
                Console.WriteLine($"=== Taille du tableau : {taille} ===");

                int[] ARRAYS = aleatoire(1, taille, 1000);


                int[] arraysBulles = new int[ARRAYS.Length];
                int[] arraysInsertion = new int[ARRAYS.Length];
                for (int i = 0; i < ARRAYS.Length; i++)
                {
                    arraysBulles[i] = ARRAYS[i];
                    arraysInsertion[i] = ARRAYS[i];
                }

                // Tri à bulles
                Stopwatch sw = new Stopwatch();
                sw.Start();
                DECROISANT(arraysBulles);
                sw.Stop();
                Console.WriteLine("Tri lent décroissant :");
                //printable(arraysBulles);
                Console.WriteLine("Temps d’exécution : " + sw.Elapsed.TotalMilliseconds + " ms\n");

                // Tri par insertion décroissant
                sw.Restart();
                InsertionDecroissant(arraysInsertion);
                sw.Stop();
                Console.WriteLine("Tri rapide décroissant :");
                //printable(arraysInsertion);
                Console.WriteLine("Temps d’exécution : " + sw.Elapsed.TotalMilliseconds + " ms\n");

            }

    }
        // Génération d’un tableau aléatoire
        static int[] aleatoire(int l1 = 1, int l2 = 10, int l3 = 100)
        {
            int[] tableau = new int[l2];
            Random random = new Random();
            for (int i = 0; i < tableau.Length; i++)
            {
                int o = random.Next(l1, l3 + 1);
                while (Array.IndexOf(tableau, o) != -1)
                {
                    o = random.Next(l1, l3 + 1);
                }
                tableau[i] = o;
            }
            return tableau;
        }

        // Tri  décroissant(methode appris en classe)
        static int[] DECROISANT(int[] tableau)
        {
            for (int Pass = 0; Pass < tableau.Length; Pass++)
            {
                for (int i = 0; i < tableau.Length - 1; i++)
                {
                    if (tableau[i] < tableau[i + 1])
                    {
                        int v = tableau[i];
                        tableau[i] = tableau[i + 1];
                        tableau[i + 1] = v;
                    }
                }
            }
            return tableau;
        }

        // Tri par insertion décroissant
        static void InsertionDecroissant(int[] t)
        {
            for (int i = 1; i < t.Length; i++)
            {
                int key = t[i];
                int j = i - 1;
                while (j >= 0 && t[j] < key)
                {
                    t[j + 1] = t[j];
                    j--;
                }
                t[j + 1] = key;
            }
        }

        //Affichage
        static void printable(int[] tableau)
        {
            for (int i = 0; i < tableau.Length; i++)
            {
                Console.Write(tableau[i] + " ");
            }
            Console.WriteLine();
        }
    }

}
